import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';

class LocaleController extends GetxController {
  static const _boxKey = 'locale';
  static const _localeKey = 'app_locale';

  final _locale = 'es'.obs; // Default to Spanish

  String get currentLocale => _locale.value;

  @override
  void onInit() {
    super.onInit();
    _loadSaved();
  }

  void _loadSaved() {
    try {
      final box = Hive.box('settings');
      final saved = box.get(_localeKey, defaultValue: 'es');
      _locale.value = saved;
      // Apply immediately
      final locale = _parseLocale(saved);
      Get.updateLocale(locale);
    } catch (_) {
      _locale.value = 'es';
      Get.updateLocale(const Locale('es'));
    }
  }

  void changeLocale(String langCode) {
    _locale.value = langCode;
    final locale = _parseLocale(langCode);
    Get.updateLocale(locale);

    // Persist
    try {
      final box = Hive.box('settings');
      box.put(_localeKey, langCode);
    } catch (_) {}
  }

  Locale _parseLocale(String code) {
    switch (code) {
      case 'en':
        return const Locale('en', 'US');
      case 'es':
        return const Locale('es', 'ES');
      default:
        return const Locale('es', 'ES');
    }
  }

  String getLanguageName(String code) {
    switch (code) {
      case 'en':
        return 'English';
      case 'es':
        return 'Español';
      default:
        return code;
    }
  }
}
