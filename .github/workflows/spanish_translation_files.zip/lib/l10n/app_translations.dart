import 'package:get/get.dart';

class AppTranslations extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
        'en': _en,
        'es': _es,
      };

  // ═══════════════════════════════════════════════════════════════
  // ENGLISH — Keys match exactly what the code uses with .tr
  // ═══════════════════════════════════════════════════════════════
  static const Map<String, String> _en = {
    // ── App ──
    'Uncensored Local AI': 'Uncensored Local AI',
    'Run uncensored LLMs natively on any device 🔓':
        'Run uncensored LLMs natively on any device 🔓',

    // ── Navigation ──
    'Chat': 'Chat',
    'Models': 'Models',
    'Settings': 'Settings',

    // ── Chat Screen ──
    'Chat History': 'Chat History',
    'New Chat': 'New Chat',
    'Select Model': 'Select Model',
    'No model selected': 'No model selected',
    'Loading...': 'Loading...',
    'Loading model...': 'Loading model...',
    'Ready': 'Ready',
    'No Model': 'No Model',
    'Active': 'Active',
    'Unload': 'Unload',
    'Browse All': 'Browse All',
    'Toggle sidebar': 'Toggle sidebar',
    'Toggle theme': 'Toggle theme',
    'How can I help you?': 'How can I help you?',
    'Type a message below to get started.':
        'Type a message below to get started.',
    'Select a model first to begin chatting.':
        'Select a model first to begin chatting.',
    'Ask anything...': 'Ask anything...',
    'Send': 'Send',
    'Stop': 'Stop',

    // ── Model Loading Overlay ──
    'Importing file...': 'Importing file...',
    'Large models (5GB+) take about 30-50 seconds for Android to process. Please wait.':
        'Large models (5GB+) take about 30-50 seconds for Android to process. Please wait.',
    'Cancel': 'Cancel',

    // ── Model Library ──
    'Import': 'Import',
    'Import Model': 'Import Model',
    'Import .gguf File': 'Import .gguf File',
    'Select a single model file': 'Select a single model file',
    'Import from Folder': 'Import from Folder',
    'Scan folder for .gguf files': 'Scan folder for .gguf files',
    'Add from URL': 'Add from URL',
    'Download a .gguf model from a URL':
        'Download a .gguf model from a URL',
    'Add Model from URL': 'Add Model from URL',
    'Model Name': 'Model Name',
    'e.g. Mistral 7B Uncensored': 'e.g. Mistral 7B Uncensored',
    'Download URL': 'Download URL',
    'https://huggingface.co/.../model.gguf':
        'https://huggingface.co/.../model.gguf',
    'Add Model': 'Add Model',
    'Missing Info': 'Missing Info',
    'Please enter both name and URL.': 'Please enter both name and URL.',
    'Invalid URL': 'Invalid URL',
    'URL must start with http:// or https://':
        'URL must start with http:// or https://',
    'No models in catalog.': 'No models in catalog.',
    'No models match this filter.': 'No models match this filter.',
    'All': 'All',
    'Downloaded': 'Downloaded',
    'Uncensored': 'Uncensored',
    'Custom': 'Custom',
    'Load': 'Load',
    'Load Model': 'Load Model',
    'Delete': 'Delete',
    'Delete Model File': 'Delete Model File',
    'Delete model file': 'Delete model file',
    'Remove': 'Remove',
    'Remove Custom Model': 'Remove Custom Model',
    'Remove from library': 'Remove from library',
    'Removed': 'Removed',
    'LOADED': 'LOADED',
    'LOADING': 'LOADING',
    'DOWNLOADING': 'DOWNLOADING',
    'No chats yet': 'No chats yet',
    'Chats saved locally': 'Chats saved locally',
    'Delete Chat': 'Delete Chat',

    // ── Settings Screen ──
    'Appearance': 'Appearance',
    'Dark Mode': 'Dark Mode',
    'Using dark theme': 'Using dark theme',
    'Using light theme': 'Using light theme',
    'Battery Optimization': 'Battery Optimization',
    'Disable to prevent background killing':
        'Disable to prevent background killing',
    'Global System Prompt': 'Global System Prompt',
    'Applied to all new chats. Existing chats keep their own prompt.':
        'Applied to all new chats. Existing chats keep their own prompt.',
    'e.g. You are a helpful assistant...':
        'e.g. You are a helpful assistant...',
    'Clear Prompt': 'Clear Prompt',
    'Cleared': 'Cleared',
    'Global system prompt removed.': 'Global system prompt removed.',
    'Temperature': 'Temperature',
    'Hardware Configuration': 'Hardware Configuration',
    'Compute Device': 'Compute Device',
    'Apply Recommended Settings': 'Apply Recommended Settings',
    'Auto Config Applied': 'Auto Config Applied',
    'Manual Override': 'Manual Override',
    'GPU (Vulkan)': 'GPU (Vulkan)',
    'GPU (OpenCL)': 'GPU (OpenCL)',
    'GPU Layers': 'GPU Layers',
    'CPU Only': 'CPU Only',
    'If the app crashes when loading a model, reduce GPU layers or switch to CPU. Reload the model after changing settings.':
        'If the app crashes when loading a model, reduce GPU layers or switch to CPU. Reload the model after changing settings.',
    'Local API Server': 'Local API Server',
    'Expose the loaded model to OpenAI-compatible local clients.':
        'Expose the loaded model to OpenAI-compatible local clients.',
    'Local API server': 'Local API server',
    'Allow External Connections': 'Allow External Connections',
    'Listen on 0.0.0.0 instead of localhost':
        'Listen on 0.0.0.0 instead of localhost',
    'Anyone on your network can access your loaded model.':
        'Anyone on your network can access your loaded model.',
    'Starting': 'Starting',
    'Running': 'Running',
    'Busy': 'Busy',
    'Stopped': 'Stopped',
    'No model loaded': 'No model loaded',
    'Port': 'Port',
    'Use API key "local" in clients that require one.':
        'Use API key "local" in clients that require one.',
    'Invalid Port': 'Invalid Port',
    'Choose a port from 1024 to 65535.':
        'Choose a port from 1024 to 65535.',
    'Local API Updated': 'Local API Updated',
    'Local API Error': 'Local API Error',
    'Settings Error': 'Settings Error',
    'Sample Endpoints & Testing': 'Sample Endpoints & Testing',
    'Storage': 'Storage',
    'Danger Zone': 'Danger Zone',
    'Delete All Chats': 'Delete All Chats',
    'Delete All Chats?': 'Delete All Chats?',
    'This cannot be undone.': 'This cannot be undone.',
    'Delete All': 'Delete All',
    'Done': 'Done',
    'All chats deleted.': 'All chats deleted.',
    'Clear Temporary Cache': 'Clear Temporary Cache',
    'Uncensored Local AI v2.0.0': 'Uncensored Local AI v2.0.0',
    'Powered by llamadart + llama.cpp': 'Powered by llamadart + llama.cpp',
    'Debugging': 'Debugging',
    'App Logs': 'App Logs',
    'View logs, errors & share with developers':
        'View logs, errors & share with developers',
    'Language': 'Language',

    // ── Logs Screen ──
    'Logs': 'Logs',
    'Info': 'Info',
    'Warnings': 'Warnings',
    'Errors': 'Errors',
    'Copy Logs to Share': 'Copy Logs to Share',
    'No logs yet.': 'No logs yet.',
    'Clear logs': 'Clear logs',
    'All logs cleared.': 'All logs cleared.',
    'All logs copied to clipboard. Share on Telegram or GitHub!':
        'All logs copied to clipboard. Share on Telegram or GitHub!',
    'Paste in Telegram or GitHub Issues to share with developers.':
        'Paste in Telegram or GitHub Issues to share with developers.',
    'Copied': 'Copied',
    'Logs Copied!': 'Logs Copied!',
    'Copy all logs': 'Copy all logs',

    // ── API Endpoints ──
    'Sample Endpoints': 'Sample Endpoints',
    'How to Access': 'How to Access',
    'The app runs a local HTTP server compatible with the OpenAI API format...':
        'The app runs a local HTTP server compatible with the OpenAI API format...',
    'Serve the local API to other apps': 'Serve the local API to other apps',
    'List available models (currently loaded model).':
        'List available models (currently loaded model).',
    'Generate a chat completion. Accepts messages array in standard format.':
        'Generate a chat completion. Accepts messages array in standard format.',
    'Test': 'Test',
    'Test Output': 'Test Output',
    'Fetching...': 'Fetching...',
    'API server is not running': 'API server is not running',
    'Error': 'Error',

    // ── Splash Screen ──
    'Initializing...': 'Initializing...',
    'Setting up storage...': 'Setting up storage...',
    'Loading model catalog...': 'Loading model catalog...',
    'Preparing AI engine...': 'Preparing AI engine...',
    'Preparing local API...': 'Preparing local API...',
    'Setting up background services...': 'Setting up background services...',
    'Ready!': 'Ready!',

    // ── Background Optimizer ──
    'Background Permission': 'Background Permission',
    'This app needs to run in the background to:':
        'This app needs to run in the background to:',
    'Continue model downloads when the screen is off':
        'Continue model downloads when the screen is off',
    'Keep AI inference running without interruption':
        'Keep AI inference running without interruption',
    'Please disable battery optimization for this app on the next screen.':
        'Please disable battery optimization for this app on the next screen.',
    'Later': 'Later',
    'Open Settings': 'Open Settings',

    // ── LLM Service ──
    'Preparing...': 'Preparing...',
    'Unloading previous model...': 'Unloading previous model...',
    'Loading into memory...': 'Loading into memory...',
    'Not enough RAM to load this model...':
        'Not enough RAM to load this model...',
    'Try a smaller model (e.g. Gemma 2 2B at 1.6 GB).':
        'Try a smaller model (e.g. Gemma 2 2B at 1.6 GB).',

    // ── Wakelock Service ──
    'AI Model Active': 'AI Model Active',
    'Download in progress — keep the app open':
        'Download in progress — keep the app open',
    'Download in progress': 'Download in progress',
    'Unload model from memory': 'Unload model from memory',
  };

  // ═══════════════════════════════════════════════════════════════
  // SPANISH — All UI text translated
  // ═══════════════════════════════════════════════════════════════
  static const Map<String, String> _es = {
    // ── App ──
    'Uncensored Local AI': 'IA Local Sin Censura',
    'Run uncensored LLMs natively on any device 🔓':
        'Ejecuta LLMs sin censura directamente en tu dispositivo 🔓',

    // ── Navigation ──
    'Chat': 'Chat',
    'Models': 'Modelos',
    'Settings': 'Ajustes',

    // ── Chat Screen ──
    'Chat History': 'Historial de Chat',
    'New Chat': 'Nuevo Chat',
    'Select Model': 'Seleccionar Modelo',
    'No model selected': 'Ningún modelo seleccionado',
    'Loading...': 'Cargando...',
    'Loading model...': 'Cargando modelo...',
    'Ready': 'Listo',
    'No Model': 'Sin Modelo',
    'Active': 'Activo',
    'Unload': 'Descargar',
    'Browse All': 'Ver Todos',
    'Toggle sidebar': 'Alternar barra lateral',
    'Toggle theme': 'Cambiar tema',
    'How can I help you?': '¿En qué puedo ayudarte?',
    'Type a message below to get started.':
        'Escribe un mensaje abajo para empezar.',
    'Select a model first to begin chatting.':
        'Selecciona un modelo para empezar a chatear.',
    'Ask anything...': 'Pregunta lo que sea...',
    'Send': 'Enviar',
    'Stop': 'Detener',

    // ── Model Loading Overlay ──
    'Importing file...': 'Importando archivo...',
    'Large models (5GB+) take about 30-50 seconds for Android to process. Please wait.':
        'Los modelos grandes (5GB+) tardan entre 30-50 segundos para que Android los procese. Por favor espera.',
    'Cancel': 'Cancelar',

    // ── Model Library ──
    'Import': 'Importar',
    'Import Model': 'Importar Modelo',
    'Import .gguf File': 'Importar Archivo .gguf',
    'Select a single model file': 'Selecciona un archivo de modelo',
    'Import from Folder': 'Importar desde Carpeta',
    'Scan folder for .gguf files': 'Buscar archivos .gguf en la carpeta',
    'Add from URL': 'Agregar desde URL',
    'Download a .gguf model from a URL':
        'Descargar un modelo .gguf desde una URL',
    'Add Model from URL': 'Agregar Modelo desde URL',
    'Model Name': 'Nombre del Modelo',
    'e.g. Mistral 7B Uncensored': 'ej. Mistral 7B Sin Censura',
    'Download URL': 'URL de Descarga',
    'https://huggingface.co/.../model.gguf':
        'https://huggingface.co/.../model.gguf',
    'Add Model': 'Agregar Modelo',
    'Missing Info': 'Datos Faltantes',
    'Please enter both name and URL.': 'Por favor ingresa nombre y URL.',
    'Invalid URL': 'URL Inválida',
    'URL must start with http:// or https://':
        'La URL debe comenzar con http:// o https://',
    'No models in catalog.': 'No hay modelos en el catálogo.',
    'No models match this filter.': 'Ningún modelo coincide con este filtro.',
    'All': 'Todos',
    'Downloaded': 'Descargados',
    'Uncensored': 'Sin Censura',
    'Custom': 'Personalizados',
    'Load': 'Cargar',
    'Load Model': 'Cargar Modelo',
    'Delete': 'Eliminar',
    'Delete Model File': 'Eliminar Archivo de Modelo',
    'Delete model file': 'Eliminar archivo de modelo',
    'Remove': 'Quitar',
    'Remove Custom Model': 'Quitar Modelo Personalizado',
    'Remove from library': 'Quitar de la biblioteca',
    'Removed': 'Eliminado',
    'LOADED': 'CARGADO',
    'LOADING': 'CARGANDO',
    'DOWNLOADING': 'DESCARGANDO',
    'No chats yet': 'Aún no hay chats',
    'Chats saved locally': 'Chats guardados localmente',
    'Delete Chat': 'Eliminar Chat',

    // ── Settings Screen ──
    'Appearance': 'Apariencia',
    'Dark Mode': 'Modo Oscuro',
    'Using dark theme': 'Usando tema oscuro',
    'Using light theme': 'Usando tema claro',
    'Battery Optimization': 'Optimización de Batería',
    'Disable to prevent background killing':
        'Desactivar para evitar que el sistema cierre la app en segundo plano',
    'Global System Prompt': 'Prompt del Sistema (Global)',
    'Applied to all new chats. Existing chats keep their own prompt.':
        'Se aplica a todos los chats nuevos. Los chats existentes mantienen su propio prompt.',
    'e.g. You are a helpful assistant...': 'ej. Eres un asistente útil...',
    'Clear Prompt': 'Limpiar Prompt',
    'Cleared': 'Limpiado',
    'Global system prompt removed.': 'Prompt global del sistema eliminado.',
    'Temperature': 'Temperatura',
    'Hardware Configuration': 'Configuración de Hardware',
    'Compute Device': 'Dispositivo de Cómputo',
    'Apply Recommended Settings': 'Aplicar Configuración Recomendada',
    'Auto Config Applied': 'Configuración Automática Aplicada',
    'Manual Override': 'Configuración Manual',
    'GPU (Vulkan)': 'GPU (Vulkan)',
    'GPU (OpenCL)': 'GPU (OpenCL)',
    'GPU Layers': 'Capas GPU',
    'CPU Only': 'Solo CPU',
    'If the app crashes when loading a model, reduce GPU layers or switch to CPU. Reload the model after changing settings.':
        'Si la app se cierra al cargar un modelo, reduce las capas GPU o cambia a CPU. Recarga el modelo después de cambiar la configuración.',
    'Local API Server': 'Servidor API Local',
    'Expose the loaded model to OpenAI-compatible local clients.':
        'Expone el modelo cargado a clientes locales compatibles con OpenAI.',
    'Local API server': 'Servidor API local',
    'Allow External Connections': 'Permitir Conexiones Externas',
    'Listen on 0.0.0.0 instead of localhost':
        'Escuchar en 0.0.0.0 en lugar de localhost',
    'Anyone on your network can access your loaded model.':
        'Cualquier persona en tu red puede acceder al modelo cargado.',
    'Starting': 'Iniciando',
    'Running': 'En ejecución',
    'Busy': 'Ocupado',
    'Stopped': 'Detenido',
    'No model loaded': 'Ningún modelo cargado',
    'Port': 'Puerto',
    'Use API key "local" in clients that require one.':
        'Usa la clave API "local" en clientes que la requieran.',
    'Invalid Port': 'Puerto Inválido',
    'Choose a port from 1024 to 65535.':
        'Elige un puerto entre 1024 y 65535.',
    'Local API Updated': 'API Local Actualizada',
    'Local API Error': 'Error de API Local',
    'Settings Error': 'Error de Ajustes',
    'Sample Endpoints & Testing': 'Endpoints de Ejemplo y Pruebas',
    'Storage': 'Almacenamiento',
    'Danger Zone': 'Zona de Peligro',
    'Delete All Chats': 'Eliminar Todos los Chats',
    'Delete All Chats?': '¿Eliminar Todos los Chats?',
    'This cannot be undone.': 'Esto no se puede deshacer.',
    'Delete All': 'Eliminar Todo',
    'Done': 'Listo',
    'All chats deleted.': 'Todos los chats eliminados.',
    'Clear Temporary Cache': 'Limpiar Caché Temporal',
    'Uncensored Local AI v2.0.0': 'IA Local Sin Censura v2.0.0',
    'Powered by llamadart + llama.cpp': 'Impulsado por llamadart + llama.cpp',
    'Debugging': 'Depuración',
    'App Logs': 'Registros de la App',
    'View logs, errors & share with developers':
        'Ver registros, errores y compartir con los desarrolladores',
    'Language': 'Idioma',

    // ── Logs Screen ──
    'Logs': 'Registros',
    'Info': 'Info',
    'Warnings': 'Advertencias',
    'Errors': 'Errores',
    'Copy Logs to Share': 'Copiar Registros para Compartir',
    'No logs yet.': 'Aún no hay registros.',
    'Clear logs': 'Limpiar registros',
    'All logs cleared.': 'Todos los registros eliminados.',
    'All logs copied to clipboard. Share on Telegram or GitHub!':
        'Todos los registros copiados al portapapeles. ¡Comparte en Telegram o GitHub!',
    'Paste in Telegram or GitHub Issues to share with developers.':
        'Pega en Telegram o GitHub Issues para compartir con los desarrolladores.',
    'Copied': 'Copiado',
    'Logs Copied!': '¡Registros Copiados!',
    'Copy all logs': 'Copiar todos los registros',

    // ── API Endpoints ──
    'Sample Endpoints': 'Endpoints de Ejemplo',
    'How to Access': 'Cómo Acceder',
    'The app runs a local HTTP server compatible with the OpenAI API format...':
        'La app ejecuta un servidor HTTP local compatible con el formato de API de OpenAI...',
    'Serve the local API to other apps':
        'Servir la API local a otras aplicaciones',
    'List available models (currently loaded model).':
        'Listar modelos disponibles (modelo actualmente cargado).',
    'Generate a chat completion. Accepts messages array in standard format.':
        'Genera una completación de chat. Acepta un array de mensajes en formato estándar.',
    'Test': 'Probar',
    'Test Output': 'Resultado de la Prueba',
    'Fetching...': 'Obteniendo...',
    'API server is not running': 'El servidor API no está en ejecución',
    'Error': 'Error',

    // ── Splash Screen ──
    'Initializing...': 'Inicializando...',
    'Setting up storage...': 'Configurando almacenamiento...',
    'Loading model catalog...': 'Cargando catálogo de modelos...',
    'Preparing AI engine...': 'Preparando motor de IA...',
    'Preparing local API...': 'Preparando API local...',
    'Setting up background services...': 'Configurando servicios en segundo plano...',
    'Ready!': '¡Listo!',

    // ── Background Optimizer ──
    'Background Permission': 'Permiso en Segundo Plano',
    'This app needs to run in the background to:':
        'Esta app necesita ejecutarse en segundo plano para:',
    'Continue model downloads when the screen is off':
        'Continuar descargas de modelos cuando la pantalla está apagada',
    'Keep AI inference running without interruption':
        'Mantener la inferencia de IA en ejecución sin interrupciones',
    'Please disable battery optimization for this app on the next screen.':
        'Por favor desactiva la optimización de batería para esta app en la siguiente pantalla.',
    'Later': 'Después',
    'Open Settings': 'Abrir Ajustes',

    // ── LLM Service ──
    'Preparing...': 'Preparando...',
    'Unloading previous model...': 'Descargando modelo anterior...',
    'Loading into memory...': 'Cargando en memoria...',
    'Not enough RAM to load this model...':
        'No hay suficiente RAM para cargar este modelo...',
    'Try a smaller model (e.g. Gemma 2 2B at 1.6 GB).':
        'Prueba un modelo más pequeño (ej. Gemma 2 2B con 1.6 GB).',

    // ── Wakelock Service ──
    'AI Model Active': 'Modelo IA Activo',
    'Download in progress — keep the app open':
        'Descarga en progreso — mantén la app abierta',
    'Download in progress': 'Descarga en progreso',
    'Unload model from memory': 'Descargar modelo de la memoria',
  };
}
